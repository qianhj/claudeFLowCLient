/**
 * electron-builder afterPack hook
 * 使用 @electron/rebuild 重建原生模块（如 node-pty）
 * 确保原生 .node 文件与 Electron 的 Node.js ABI 匹配
 */
const { rebuild } = require("@electron/rebuild");
const path = require("path");

exports.default = async function (context) {
  const { appOutDir, electronVersion, arch } = context;

  // 重建打包后 app 目录中的原生模块
  const modulesDir = path.join(appOutDir, "resources", "node_modules");

  console.log(`[rebuild] Rebuilding native modules in ${modulesDir}`);
  console.log(`[rebuild] Electron version: ${electronVersion}, arch: ${arch}`);

  try {
    await rebuild({
      buildPath: modulesDir,
      electronVersion,
      arch,
      onlyModules: ["node-pty"],
    });
    console.log("[rebuild] Done.");
  } catch (err) {
    console.error("[rebuild] Failed:", err);
    // 不抛出错误，允许打包继续（终端功能可能不可用但其他功能正常）
  }
};
