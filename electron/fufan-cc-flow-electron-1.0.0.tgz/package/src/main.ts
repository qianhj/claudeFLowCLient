import { app, BrowserWindow, shell, Menu } from "electron";
import { fork, ChildProcess } from "child_process";
import path from "path";
import http from "http";

const isDev = !app.isPackaged;
const PORT = 3001;

let mainWindow: BrowserWindow | null = null;
let serverProcess: ChildProcess | null = null;

// ---------- 启动后端进程（仅生产模式）----------
function startServer(): void {
  const serverEntry = path.join(
    process.resourcesPath,
    "server",
    "dist",
    "index.js"
  );

  serverProcess = fork(serverEntry, [], {
    env: {
      ...process.env,
      PORT: String(PORT),
      NODE_ENV: "production",
      // node-pty 原生模块路径指向资源目录
      ELECTRON_RESOURCES_PATH: process.resourcesPath,
    },
    stdio: "pipe",
  });

  serverProcess.stdout?.on("data", (d) => console.log("[server]", d.toString().trim()));
  serverProcess.stderr?.on("data", (d) => console.error("[server]", d.toString().trim()));

  serverProcess.on("exit", (code) => {
    console.log(`[server] exited with code ${code}`);
  });
}

// ---------- 轮询等待后端就绪 ----------
function waitForServer(maxRetries = 40, intervalMs = 500): Promise<void> {
  return new Promise((resolve, reject) => {
    let retries = 0;

    const check = () => {
      const req = http.get(`http://localhost:${PORT}/api/health`, (res) => {
        if (res.statusCode === 200) {
          resolve();
        } else {
          retry();
        }
      });
      req.on("error", retry);
      req.setTimeout(300, () => { req.destroy(); retry(); });
    };

    const retry = () => {
      retries++;
      if (retries >= maxRetries) {
        reject(new Error(`Backend did not start after ${maxRetries} retries`));
      } else {
        setTimeout(check, intervalMs);
      }
    };

    check();
  });
}

// ---------- 创建主窗口 ----------
async function createWindow(): Promise<void> {
  if (!isDev) {
    startServer();
    try {
      await waitForServer();
    } catch (err) {
      console.error("Backend failed to start:", err);
    }
  }

  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 900,
    minHeight: 600,
    title: "Fufan CC Flow",
    backgroundColor: "#13111C",
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
    },
    // Windows 下使用自定义边框
    frame: true,
    show: false,
  });

  // 加载地址：开发用 Vite dev server，生产用 Express
  const startUrl = isDev
    ? "http://localhost:5173"
    : `http://localhost:${PORT}`;

  mainWindow.loadURL(startUrl);

  // 窗口准备好后再显示，避免白屏闪烁
  mainWindow.once("ready-to-show", () => {
    mainWindow?.show();
    if (isDev) mainWindow?.webContents.openDevTools();
  });

  // 外部链接用系统浏览器打开
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: "deny" };
  });

  mainWindow.on("closed", () => {
    mainWindow = null;
  });
}

// ---------- 去掉默认菜单栏 ----------
Menu.setApplicationMenu(null);

// ---------- 应用生命周期 ----------
app.whenReady().then(createWindow);

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") {
    app.quit();
  }
});

app.on("activate", () => {
  if (BrowserWindow.getAllWindows().length === 0) {
    createWindow();
  }
});

app.on("before-quit", () => {
  serverProcess?.kill();
});
