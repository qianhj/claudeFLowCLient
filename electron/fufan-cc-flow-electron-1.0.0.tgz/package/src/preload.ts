// 预加载脚本运行在隔离上下文中，目前无需暴露任何 API
// 保持 contextIsolation: true 以确保安全性
